#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <unistd.h>
#include "plugin_api.h"

#define ANAGRAM_STR "anagram"

static char *g_lib_name = "lib12nsrN32511.so";
static char *g_plugin_purpose = "Поиск файлов, содержащих заданную анаграмму";
static char *g_plugin_author = "Ращукин Никита Сергеевич N32511";
static struct plugin_option g_po_arr[] = {
        {
                {
                    ANAGRAM_STR,
                    required_argument,
                    0,0,
                },
                "Поиск файлов, содержащих заданную анаграмму"
        }
};

static int g_po_arr_len = sizeof(g_po_arr)/sizeof(g_po_arr[0]);

int char_counter(char*);
int input_check(char*); //Проверяет исходную строку на недопустимые символы
char* remove_spaces(char*); //Удаляет пробелы
char* lower(char*); //Переводит все символы в строке в нижний регистр

int cmp(const void * x, const void * y) { // Сравнение двух символов
    char charX = *(char*)x;
    char charY = *(char*)y;
    if (charX == '\n') {
        return 1;
    }
    else if (charY == '\n') {
        return -1;
    }
    else {
        return charX - charY;
    }
}

int plugin_get_info(struct plugin_info* ppi) {
    if (!ppi) {
        fprintf(stderr, "Ошибка передачи аргумента\n");
        return -1;
    }

    ppi->plugin_purpose = g_plugin_purpose;
    ppi->plugin_author = g_plugin_author;
    ppi->sup_opts_len = g_po_arr_len;
    ppi->sup_opts = g_po_arr;
    return 0;
}

int plugin_process_file(const char *fname, struct option in_opts[], size_t in_opts_len) {

    int ret = 0;//Переменная возврата программы (по умолчанию ошибка)

    char *DEBUG = getenv("LAB12DEBUG");

    if (!fname || !in_opts || !in_opts_len) {
        errno = EINVAL;
        return -1;
    }

    char *input_string = NULL;

    for (size_t i = 0; i < in_opts_len; ++i) {
        if (!strcmp(in_opts[i].name, ANAGRAM_STR)) {
            input_string = (char *) in_opts[i].flag;
        }
    }

    int saved_errno = 0;
    FILE *fp = fopen(fname, "r");
    if (fp == NULL) {
        fprintf(stderr, "%s Ошибка чтения файлы %s\n", g_lib_name, fname);
        return -1;
    }

    if (!input_check(input_string)) {
        fprintf(stderr, "Ошибка введен недопустимый символ\n");
        ret -= 1;
        goto END;
    }

    int fd = open(fname, O_RDONLY);
    if (fd < 0) {
        if (DEBUG) {
            fprintf(stderr, "DEBUG %s: Не удалось открыть проверочный файл: %s\n", g_lib_name, fname);
        }
        return -1;
    }

    struct stat st = {0};
    int res = fstat(fd, &st);
    if (res < 0) {
        if (DEBUG) {
            fprintf(stderr, "DEBUG: %s: Не удалось получить информаццию о проверочном файле: %s\n", g_lib_name, fname);
        }
        saved_errno = errno;
        goto END;
    }

    if (st.st_size == 0) {
        if (DEBUG) {
            fprintf(stderr, "DEBUG %s: Проверочный файл %s пуст\n", g_lib_name, fname);
        }
        saved_errno = ERANGE;
        goto END;
    }

    input_string = remove_spaces(input_string);
    input_string = lower(input_string);

    int last_n;
    char* sort_input = malloc(strlen(input_string) + 1);
    for (int i = 0; i < (int) strlen(input_string); ++i) {
        sort_input[i] = input_string[i];
        last_n = i;
    }
    sort_input[last_n + 1] = '\n';

    qsort(sort_input, (int) strlen(sort_input), sizeof(char), cmp);

    char *line = malloc(strlen(input_string) * 2);
    size_t len = 0;
    char ch;
    int k = 0;
    char *block = malloc(strlen(sort_input));
    while ((ch = getc(fp)) != EOF) {
        if (ch == '\n') {
            k = 0;
            if (line)
                free(line);
            line = malloc(strlen(input_string) * 2);
            continue;
        }
        if (ch == ' ') {
            continue;
        }
        line[k++] = ch;
        line[k] = '\n';
        if (k < strlen(sort_input) - 1) {
            continue;
        }
        line = lower(line);
        ret = 1;
        if (strstr(line, input_string)) {
            ret = 0;
            goto END;
        }

        int count = strlen(line) - strlen(sort_input) + 1;

        for (int index = 0; index < count; ++index) {
            for (int j = 0, i = index; j < (int) strlen(sort_input); ++j) {
                block[j] = line[i];
                block[j + 1] = '\n';
                i++;
            }
            qsort(block, k, sizeof(char), cmp);
            if (!strncmp(block, sort_input, strlen(sort_input))) {
                ret = 0;
                goto END;
            }
            else {
                char *new_line = malloc(strlen(line));
                strcpy(new_line, line + 1);
                free(line);
                line = new_line;
                new_line = NULL;
                line[k-1] = 'a';
                line[k--] = '\n';
                break;
            }
        }
    }

    END:
        if (line) free(line);
        if (block) free(block);
	if (sort_input) free(sort_input);
        fclose(fp);
        errno = saved_errno;
        return ret;
}

int input_check(char *str) {
    int res = 0;

    for (int i = 0; i < (int)strlen(str); ++i) {
        if ((str[i] >= 33) && (str[i] <= 126))
            res = 1;
    }
    return res;
}

char* remove_spaces(char* str) {
    char *out = str;
    char *put = str;

    for (; *str != '\0'; ++str) {
        if (*str != ' ')
            *put++ = *str;
    }

    *put = '\0';
    return out;
}

char* lower(char *str) {
    for (int i = 0; i < (int)strlen(str); ++i) {
        str[i] = tolower((unsigned char)str[i]);
    }
    return str;
}






















