#define _GNU_SOURCE
#define _XOPEN_SOURCE 500
#define UNUSED(x) (void)(x)
#include <string.h>
#include <stdio.h>
#include <ftw.h>
#include <getopt.h>
#include <dlfcn.h>
#include <dirent.h>
#include <unistd.h>
#include "plugin_api.h"


struct option *long_options;
const char *true_plugin(const char *filename) {
    const char *extension = strrchr(filename, '.');
    if (!extension || extension==filename) return "";
    return extension + 1;
}

void totalfree();
struct info_libraries {
    struct plugin_option *opts;
    int opts_len;
    char *name;
    void *dl;
};

struct info_libraries *lib_info;
int walk_func(const char*, const struct stat*, int, struct FTW*);

void lab_author();
struct opt_search {
    unsigned int OR;
    unsigned int AND;
    unsigned int NOT;
};

struct opt_search operations = {0, 0, 0};
int count_so = 0;
char** optarg_list = NULL;
int optarg_counter = 0;
char *way_to_plugins;
char* current_dirway;
int count_P = 0;
int *dl_order;
int *libs_order = NULL;

int main(int argc, char *argv[]) {

    if (argc == 1) {
        fprintf(stderr, "Информация по выполненной работе %s\nДля дальнейшего получения информции введите '-h'\n", argv[0]);
        return 1;
    }
    atexit(&totalfree);

    char *DEBUG = getenv("LAB12DEBUG");
    current_dirway= getcwd(NULL, 255);
    char *dir_way = "\n";
    way_to_plugins = get_current_dir_name(); // Получаем полный путь к текущему каталогу


    for (int i = 0; i < argc; ++i) {
        if (strcmp(argv[i], "-P") == 0) {
            if (count_P) {
                fprintf(stderr, "Ошибка: повторное использование '-P' запрещено\n");
                return 1;
            }
            if (i == (argc - 1)) {
                fprintf(stderr, "Ошибка: к опции '-P' должен быть передан аргумент\n");
                return 1;
            }
            DIR *d;
            if ((d = opendir(argv[i+1])) == NULL) {
                perror(argv[i+1]);
                return 1;
            }
            else {
                closedir(d);
                free(way_to_plugins);
                char *P_arg = argv[i+1];
                if (P_arg[0] == '.') {
                    char mass[128];
                    for (int i = 0; i < (int)strlen(P_arg); ++i) {
                        P_arg[i] = P_arg[i+1];
                    }
                    strcpy(mass, current_dirway);
                    strcat(mass, P_arg);
                    way_to_plugins = mass;

                    if (way_to_plugins[strlen(way_to_plugins)-1] == '/')
                        way_to_plugins[strlen(way_to_plugins)-1] = '\0';
                    else
                        way_to_plugins[strlen(way_to_plugins)] = '\0';
                }
                else {
                    way_to_plugins = argv[i + 1];
                }
                count_P = 1;
            }
        }
        else if (strcmp(argv[i], "-v") == 0) {
            lab_author();
            return 0;
        }
        else if (strcmp(argv[i], "-h") == 0) {
            //Написать все виды опций по типу -P -A и тд.
            return 0;
        }
    }

    char plugin_way[512];
    strcpy(plugin_way, way_to_plugins);

    DIR *d;
    struct dirent *dir;
    d = opendir(way_to_plugins);
    if (d != NULL) {
        while ((dir = readdir(d)) != NULL) {
            if ((dir->d_type) == 8) {
                count_so++;
            }
        }
        closedir(d);
    }
    else {
        perror("opendir");
        exit(EXIT_FAILURE);
    }

    lib_info = (struct info_libraries*)malloc(count_so*sizeof(struct info_libraries));
    if (lib_info == 0) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    count_so = 0;
    d = opendir(way_to_plugins);
    if (d != NULL) {
        while ((dir = readdir(d)) != NULL) {
            if ((dir->d_type) == 8) {
                if (strcmp(true_plugin(dir->d_name), "so") == 0)  {
                    char fullname[512] = {0};
                    strcpy(fullname, plugin_way);
                    strcat(fullname, "/");
                    strcat(fullname, dir->d_name);
                    void *dl = dlopen(fullname, RTLD_LAZY);
                    if (!dl) {
                        fprintf(stderr, "Ошибка: dlopen был завершен с ошибкой: %s\n", dlerror());
                        continue;
                    }
                    void *func = dlsym(dl, "plugin_get_info");
                    if (!func) {
                        fprintf(stderr, "Ошибка: dlysm был завершен с ошибкой: %s\n", dlerror());
                    }
                    struct plugin_info pi = {0};
                    typedef int (*pgi_func_t)(struct plugin_info*);
                    pgi_func_t pgi_func = (pgi_func_t)func;
                    int ret = pgi_func(&pi);
                    if (ret < 0) {
                        fprintf(stderr, "Ошибка получения информации о расширяемой библиотеке:\n");
                    }
                    lib_info[count_so].name = dir->d_name;
                    lib_info[count_so].opts = pi.sup_opts;
                    lib_info[count_so].opts_len = pi.sup_opts_len;
                    lib_info[count_so].dl = dl;
                    if (DEBUG) {
                        printf("DEBUG: Обнаружена динамическая библиотека:\nИмя библиотеки: %s\nНазначение библиотеки: %s\nСоздатель библиотеки: %s\n", dir->d_name, pi.plugin_purpose, pi.plugin_author);
                    }
                    count_so++;
                }
            }
        }
        closedir(d);
    }

    size_t opt_count = 0;
    for (int i = 0; i < count_so; ++i) {
        opt_count += lib_info[i].opts_len;
    }

    long_options = (struct option*) malloc(opt_count*sizeof(struct option));
    if (!long_options) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    opt_count = 0;
    for (int i = 0; i < count_so; i++) {
        for (int j = 0; j < lib_info[i].opts_len; ++j) {
            long_options[opt_count] = lib_info[i].opts[j].opt;
            opt_count++;
        }
    }
    int indicator;
    for (int i = 0; i < argc; i++) {
        if (strstr(argv[i],"--")) {
            indicator = 0;
            for (size_t j = 0; j < opt_count; j++) {
                if (strcmp(&argv[i][2], long_options[j].name) == 0) {
                    indicator = 1;
                }
            }
            if (indicator == 0) {
                fprintf(stderr, "Ошибка: среди списка расширяемых библиотека опция '%s' не была найдена\n", argv[i]);
                return 1;
            }
        }
    }

    int c;
    int dir_way_count = 0;
    int index_longopt = -1;
    while((c = getopt_long(argc, argv, "-P:AON", long_options, &index_longopt)) != -1) {
        switch(c) {
            case'O':
                if (!operations.OR) {
                    if (!operations.AND) {
                        operations.OR = -1;
                    }
                    else {
                        fprintf(stderr, "Ошибка: опции 'A' и 'O' не могут быть вместе использованны\n");
                        return 1;
                    }
                }
                else {
                    fprintf(stderr, "Ошибка: опция 'O' использованна более 1 раза\n");
                    return 1;
                }
                break;
            case 'A':
                if (!operations.AND) {
                    if (!operations.OR) {
                        operations.AND = 1;
                    }
                    else {
                        fprintf(stderr, "Ошибка: опции 'A' и 'O' не могут быть вместе использованны\n");
                        return 1;
                    }
                }
                else {
                    fprintf(stderr, "Ошибка: опция 'A' использованна более 1 раза\n");
                    return 1;
                }
                break;
            case 'N':
                if (!operations.NOT) {
                    operations.NOT;
                }
                else {
                    fprintf(stderr, "ОшибкаЖ опции 'N' использована более 1 раза\n");
                    return 1;
                }
                break;
            case 'P':
                break;
            case ';':
                return 1;
            case '?':
                return 1;
            default:
                if (index_longopt != -1) {
                    optarg_counter++;
                    if (DEBUG) {
                        printf("DEBUG: Обнаружена опция '%s' с аргументом '%s'\n", long_options[index_longopt].name, optarg);
                    }
                    libs_order = (int*) realloc(libs_order, optarg_counter *sizeof(int));
                    if (!libs_order) {
                        perror("realloc");
                        exit(EXIT_FAILURE);
                    }
                    optarg_list = (char **) realloc(optarg_list, opt_count * sizeof(char *));
                    if (!optarg_list) {
                        perror("realloc");
                        exit(EXIT_FAILURE);
                    }

                    optarg_list[optarg_counter - 1] = optarg;
                    libs_order[optarg_counter- 1] = index_longopt;
                    index_longopt = -1;
                }
                else {
                    if (dir_way_count) {
                        fprintf(stderr, "Ошибка: директория под поиски была указана дважды '%s'\n", dir_way);
                        return 1;
                    }
                    if ((d = opendir(optarg)) == NULL) {
                        perror(optarg);
                        return 1;
                    }
                    else {
                        if (optarg[0] == '.') {
                            char way[128] = {0};
                            for (int i = 0; i < (int)strlen(optarg);i++) {
                                optarg[i] = optarg[i+1];
                            }
                            strcpy(way, current_dirway);
                            strcat(way, optarg);
                            dir_way = way;
                        }
                        else {
                            dir_way = optarg;
                        }
                        dir_way_count = 1;
                        closedir(d);
                    }
                }
        }
    }

    if (strcmp(dir_way, "\n") == 0) {
        fprintf(stderr, "Ошибка: директория под поиски не была указана\n");
        return 1;
    }

    if (DEBUG) {
        printf("DEBUG: Директория под поиск требуемых файлов: %s\n", dir_way);
    }

    if ((operations.AND == 0) && (operations.OR == 0)) {
        operations.AND = 1;
    }

    if (DEBUG) {
        printf("DEBUG: Директория для динамических библиотек: %s\n", plugin_way);
        printf("\n");
    }

    dl_order = (int*)malloc(opt_count*sizeof(int));
    if (!dl_order) {
        perror("mallloc");
        exit(EXIT_FAILURE);
    }
    for (int i = 0;i < optarg_counter; ++i) {
        const char *opt_name = long_options[libs_order[i]].name;
        for (int j = 0; j < count_so; j++) {
            for (int k = 0; k < lib_info[j].opts_len; k++) {
                if (strcmp(opt_name, lib_info[j].opts[k].opt.name) == 0) {
                    dl_order[i] = j;
                }
            }
        }
    }

    int res = nftw(dir_way, walk_func, 10, FTW_PHYS || FTW_DEPTH);
    if (res < 0) {
        perror("nftw");
        return 1;
    }
    return 0;
}

typedef int (*proc_func_t)(const char *name, struct option in_opts[], size_t in_opts_len);

int walk_func(const char *fpath, const struct  stat *sb, int typeflag, struct FTW *ftwbuf) {
    char *DEBUG = getenv("LAB12DEBUG");
    if (typeflag == FTW_F) {
        int optRESULT = operations.NOT ^ operations.AND;
        for (int i = 0; i < optarg_counter; i++) {
            struct option opt = long_options[libs_order[i]];
            char* mainarg = optarg_list[i];
            if (mainarg) {
                opt.has_arg = 1;
                opt.flag = (void *)mainarg;
            }
            else {
                opt.has_arg = 0;
            }
            void *func = dlsym(lib_info[dl_order[i]].dl, "plugin_process_file");
            proc_func_t  proc_func = (proc_func_t)func;
            int res_func;
            res_func = proc_func(fpath, &opt, 1);
            if (res_func) {
                if (res_func > 0) {
                    res_func = 0;
                }
                else {
                    fprintf(stderr, "Ошибка: во время работы плагина обнаружена ошибка\n");
                    return 1;
                }
            }
            else {
                res_func = 1;
            }

            if (operations.NOT ^ operations.AND) {
                optRESULT = optRESULT & (operations.NOT ^ res_func);
            }
            else {
                optRESULT = optRESULT | (operations.NOT ^ res_func);
            }
        }

        if (optRESULT) {
            printf("Файл удовлетворяющий заданным параметрам: %s\n", fpath);
        }
        else {
            if (DEBUG) {
                printf("DEBUG: Файл, не прошедший проверку: %s\n", fpath);
            }
        }
    }

    UNUSED(sb);
    UNUSED(ftwbuf);
    return 0;
}

void lab_author() {
    printf("Cтудент: Раущкин Никита Сергеевич\n");
    printf("Группа: N32511\n");
    printf("Лабораторная работа: 1.2\n");
    printf("Вариант: 11\n");

}

void totalfree() {
    for (int i = 0; i < count_so;++i) {
        if (lib_info[i].dl)
            dlclose(lib_info[i].dl);
    }
    if (lib_info)
        free(lib_info);
    if (dl_order)
        free(dl_order);
    if (long_options)
        free(long_options);
    if (libs_order)
        free(libs_order);
    if (optarg_list)
        free(optarg_list);
    if (!count_P)
        free(way_to_plugins);
    if (current_dirway)
        free(current_dirway);

}