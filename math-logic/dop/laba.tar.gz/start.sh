#!/bin/bash
make
valgrind ./lab12nsrN32511 --anagram "New York Times" ./testlab